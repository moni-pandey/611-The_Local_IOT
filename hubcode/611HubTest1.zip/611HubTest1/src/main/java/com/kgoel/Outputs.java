package com.kgoel;

public class Outputs {
    private String redLed;
    private String yellowLed;
    private String greenLed;

    public String getRedLed() { return redLed; }

    public void setRedLed(String redLed) { this.redLed = redLed; }

    public String getYellowLed() { return yellowLed; }

    public void setYellowLed(String yellowLed) { this.yellowLed = yellowLed; }

    public String getGreenLed() { return greenLed; }

    public void setGreenLed(String greenLed) { this.greenLed = greenLed; }
}
