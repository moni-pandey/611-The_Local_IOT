package com.kgoel;

public class Inputs {
    private String name;
    private float ultraSensorDistance;
    private float minValue;
    private float maxValue;
    private String unit;

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public float getUltraSensorDistance() { return ultraSensorDistance; }

    public void setUltraSensorDistance(float ultraSensorDistance) { this.ultraSensorDistance = ultraSensorDistance; }

    public float getMinValue() { return minValue; }

    public void setMinValue(float minValue) { this.minValue = minValue; }

    public float getMaxValue() { return maxValue; }

    public void setMaxValue(float maxValue) { this.maxValue = maxValue; }

    public String getUnit() { return unit; }

    public void setUnit(String unit) { this.unit = unit; }
}
